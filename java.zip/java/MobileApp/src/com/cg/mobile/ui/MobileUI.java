package com.cg.mobile.ui;

import java.util.List;


import java.util.Scanner;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.IMobileServiceImpl;
public class MobileUI {

	public static void main(String args[]){
	IMobileService service=new IMobileServiceImpl();
	System.out.println(service.display());
	Scanner sc=new Scanner(System.in);
	while (true)
	{
		System.out.println("1.insert");
		System.out.println("2.update");
		System.out.println("3.view");
		System.out.println("4.Delete");
		System.out.println("5.Search");
		System.out.println("6.exit");
		System.out.println("enter your choice");
		int opt=sc.nextInt();
		switch(opt){
		case 1:
			/*List<Customer> list2=service.insert();
			for(Customer c: list2){
			System.out.println("CustN: "+c.getCustomername());
			System.out.println("mail: "+c.getMailid());
			System.out.println("ph: "+c.getPhoneno());
			System.out.println("pdate: "+c.getPurchasedate());
			System.out.println("pid: " +c.getPurchaseid());
			System.out.println("mid: " +c.getMobileid());
			
		
		}*/
			break;
		case 2:break;
		case 3:
			List<Mobile> list1=service.getAllMobiles();
		for(Mobile m: list1){
		System.out.println("id: "+m.getMobileId());
		System.out.println("name: "+m.getName());
		System.out.println("price: "+m.getPrice());
		System.out.println("quantity: "+m.getQuantity());
	
	}
		break;
		case 4:


System.out.println("Enter id");

int id=sc.nextInt();

service.deleteById(id);

 
			break;
		case 5:
			System.out.println("Enter price");
			double price=sc.nextDouble();
			List<Mobile> list=service.getMobileByPrice(price);
			for(Mobile m: list){
			System.out.println("id: "+m.getMobileId());
			System.out.println("name: "+m.getName());
			System.out.println("price: "+m.getPrice());
			System.out.println("quantity: "+m.getQuantity());
		
		}
			break;
		case 6:
			System.exit(0);
		
	
	
	
	}
}}
}