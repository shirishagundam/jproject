package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public class MobileDaoImpl implements IMobileDao {

	@Override
	public String display() {
		
		return "demo for mobile app";
	}

	@Override
	public List<Mobile> getMobileByPrice(double price) {
		try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url,user,pass);
	String sql="select *from mobiles where price>=?";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setDouble(1,price);
	ResultSet rs=ps.executeQuery();
	Mobile m=null;
	List<Mobile> list=new ArrayList<>();
	while (rs.next()){
		m=new Mobile();
		m.setMobileId(rs.getInt(1));
		m.setName(rs.getString(2));
		m.setPrice(rs.getDouble(3));
		m.setQuantity(rs.getString(4));
		list.add(m);
	}
	return list;
	}
	catch(Exception e) {}
		return null;
	}

	@Override
	public List<Mobile> getAllMobiles() {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			Connection con=DriverManager.getConnection(url,user,pass);
			String sql="select *from mobiles" ;
			PreparedStatement ps=con.prepareStatement(sql);
			
			ResultSet rs=ps.executeQuery();
			Mobile m=null;
			List<Mobile> list=new ArrayList<>();
			while (rs.next()){
				m=new Mobile();
				m.setMobileId(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPrice(rs.getDouble(3));
				m.setQuantity(rs.getString(4));
				list.add(m);
			}
			return list;
			}
			catch(Exception e) {}
				return null;
			
	}

	@Override

		public String deleteById(int id) {
try
			{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
			String sql="delete from mobiles where mobileid=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setDouble(1,id );
			int i=ps.executeUpdate();
			return(i+"deleted......");
			}

		catch(Exception e)
{
}
		return null;
	}

/*	@Override
	public List<Customer> insert(){ 
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection con = DriverManager.getConnection (url, "system", "Capgemini123");
		String sql = "INSERT INTO purchasedetails(customername, mailid, phoneno, purchasedate,purchaseid,mobileid) VALUES (?, ?, ?,?,?, ?)";
	
	PreparedStatement statement = con.prepareStatement(sql);
	statement.setString(1, "abc");
	statement.setString(2, "shiri@gmail.com");
	statement.setString(3, "642789130");
	statement.setString(4, "2018-03-21");
	statement.setString(5, "10");
	statement.setString(6, "1001");
	int rowsInserted = statement.executeUpdate();
	if (rowsInserted > 0) {
	    System.out.println("A new user was inserted successfully!");
	}
		
	}
	catch(Exception e)
	{
	}
			return null;
		}*/

}