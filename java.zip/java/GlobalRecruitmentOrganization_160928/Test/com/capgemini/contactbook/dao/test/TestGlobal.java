package com.capgemini.contactbook.dao.test;
import static org.junit.Assert.*;

import java.util.ConcurrentModificationException;

 


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

 


import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;



 

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;


public class TestGlobal {
	ContactBookDaoImpl dao=null;

	@Before

	public void setUp() {

	dao = new ContactBookDaoImpl();

	}

	 

	@After

	public void tearDown() {

	dao = null;

	}

	@Test

	public void getId() {

	 

	EnquiryBean bean = new EnquiryBean();

	bean.setContactNo("9090909090");

	bean.setfName("Sirisha");

	bean.setlName("Gundam");

	bean.setpDomain("Java");

	bean.setpLocation("Hyderabad");

try {

	Integer ID = dao.addEnquiry(bean);

	assertNotNull(ID);

	 

	} catch (ContactBookException e) {
	e.printStackTrace();

	}
	}
	@Test
	public void getEnquiryDetails()
	{
	ContactBookDao cdao = new ContactBookDaoImpl();
	EnquiryBean b;
	 

	try {
b=cdao.getEnquiryDetails(1);
assertEquals("Aishwarya", b.getfName());
} catch (ContactBookException e) {

	e.printStackTrace();

	}
	}
}







