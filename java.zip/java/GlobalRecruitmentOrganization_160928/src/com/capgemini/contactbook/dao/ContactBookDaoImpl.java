package com.capgemini.contactbook.dao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.utility.JdbcUtility;
import com.igate.contactbook.bean.EnquiryBean;


public class ContactBookDaoImpl implements ContactBookDao {
	static Logger logger = Logger.getLogger(ContactBookDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	
	/*******************************************************************************************************
	 - Function Name	:	addEnquiry(EnquiryBean donor)
	 - Input Parameters	:	EnquiryBean enqry
	 - Return Type		:	int
	 - Throws			:  	ContactBookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	10/29/2018
	 - Description		:	Adding Enquiry details
	 ********************************************************************************************************/


	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {

		logger.info("In enquiry..");
		int enquiryId = 0;
		connection = JdbcUtility.getConnection();

		try {

			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, enqry.getfName());
			statement.setString(2, enqry.getlName());
			statement.setLong(3, Long.parseLong(enqry.getContactNo()));
			statement.setString(4, enqry.getpDomain());
			statement.setString(5, enqry.getpLocation());
			statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);

			ResultSet rs = statement.executeQuery();
			rs.next();
			enquiryId = rs.getInt(1);
		} catch (SQLException e) {
			logger.error("statement cannot be created..");
			throw new ContactBookException("statement cannot be created");
		}
		return enquiryId;

	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		logger.info(" In Enquiry details method..");
		connection = JdbcUtility.getConnection();

		try {

			statement = connection
					.prepareStatement(QueryConstants.getEnquiryDetailsQuery);
			statement.setInt(1, EnquiryID);
			
			ResultSet rs = statement.executeQuery();
			rs.next();
			EnquiryBean e = new EnquiryBean();
			e.setEnqryId(rs.getInt(1));
			e.setfName(rs.getString(2));
			e.setlName(rs.getString(3));
			e.setContactNo(String.valueOf(rs.getLong(4)));
			e.setpDomain(rs.getString(5));
			e.setpLocation(rs.getString(6));
			return e;
		}

		catch (SQLException es) {
			logger.error("statement is not created..");
			throw new ContactBookException("Sorry No details found in db");
		}

	}
}
