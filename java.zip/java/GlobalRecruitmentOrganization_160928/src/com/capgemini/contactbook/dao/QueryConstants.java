package com.capgemini.contactbook.dao;

public interface QueryConstants {
	public static final String insertQuery = "Insert into enquiry values(enquiries.nextval,?,?,?,?,?)";

	public static final String getIdQuery = "select max(enqryId) from enquiry";

	public static final String getEnquiryDetailsQuery = "select *from enquiry where enqryId=?";

}

